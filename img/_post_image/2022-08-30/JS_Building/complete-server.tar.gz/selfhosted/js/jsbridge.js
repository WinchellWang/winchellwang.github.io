// 客户端请求
var userAgent = window.navigator.userAgent
var WebViewJavascriptBridge
console.log(userAgent)

// 判断设备信息
function isIOS() {
  if (userAgent.indexOf('Mac OS X') > -1) {
    return true
  }
}

function isAndroid() {
  if (userAgent.indexOf('Android') > -1) {
    return true
  }
}

function iswx() {
  if (/MicroMessenger/gi.test(userAgent)) {
    return true;
  } else {
    return false;
  }
}

function isApp() {
  if (userAgent.includes(' ')) {
    return true;
  } else {
    return false;
  }
}

if (isIOS()) {
  function setupWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) {
      return callback(WebViewJavascriptBridge);
    }
    if (window.WVJBCallbacks) {
      return window.WVJBCallbacks.push(callback);
    }
    window.WVJBCallbacks = [callback]; // 创建一个 WVJBCallbacks 全局属性数组，并将 callback 插入到数组中。
    var WVJBIframe = document.createElement('iframe'); // 创建一个 iframe 元素
    WVJBIframe.style.display = 'none'; // 不显示
    WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__'; // 设置 iframe 的 src 属性
    document.documentElement.appendChild(WVJBIframe); // 把 iframe 添加到当前文导航上。
    setTimeout(function () {
      document.documentElement.removeChild(WVJBIframe)
    }, 0)
  }

  // 这里主要是注册 OC 将要调用的 JS 方法。
  setupWebViewJavascriptBridge(function (bridge) {
    bridge.registerHandler('getTokenSuccess', function (res) {
      window.getTokenSuccess(res)
    });
    bridge.registerHandler('getNewTokenSuccess', function (res) {
      window.getNewTokenSuccess(res)
    });
    bridge.registerHandler('getTokenRawSuccess', function (res) {
      window.getTokenRawSuccess(res)
    });
    bridge.registerHandler('getNewTokenRawSuccess', function (res) {
      window.getNewTokenRawSuccess(res)
    });
    bridge.registerHandler('h5PostResponse', function (res) {
      window.h5PostResponse(res)
    });
    bridge.registerHandler('h5GetResponse', function (res) {
      window.h5GetResponse(res)
    });
    bridge.registerHandler('loginsuccess', function (res) {
      window.loginsuccess(res)
    });
    bridge.registerHandler('realnamesuccess', function (res) {
      window.realnamesuccess(res)
    });
    bridge.registerHandler('scansuccess', function (res) {
      window.scansuccess(res)
    });
    bridge.registerHandler('doLocalsuccess', function (res) {
      window.doLocalsuccess(res)
    });
    bridge.registerHandler('getPosition', function (res) {
      window.getPosition(res)
    });
    bridge.registerHandler('doCarSuccess', function (res) {
      window.doCarSuccess(res)
    });
    bridge.registerHandler('scanSuccess', function (res) {
      window.scanSuccess(res)
    });
    bridge.registerHandler('doTakePhotoSuccess', function (res) {
      window.doTakePhotoSuccess(res)
    });
    bridge.registerHandler('doTakeVideoSuccess', function (res) {
      window.doTakeVideoSuccess(res)
    });
    bridge.registerHandler('selectSuccess', function (res) {
      window.selectSuccess(res)
    });
    bridge.registerHandler('compressSuccess', function (res) {
      window.compressSuccess(res)
    });
  });
}

// 注册JS调用原生方法
function getToken() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('getToken', {
      getToken: 'getTokenSuccess'
    })
  } else {
    window.SzdUserInfoJsbridge && window.SzdUserInfoJsbridge.getToken('getTokenSuccess')
  }
}

function getNewToken() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('getNewToken', {
      getNewToken: 'getNewTokenSuccess'
    })
  } else {
    window.SzdUserInfoJsbridge && window.SzdUserInfoJsbridge.getNewToken('getNewTokenSuccess')
  }
}

function getTokenRaw() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('getTokenRaw', {
      getTokenRaw: 'getTokenRawSuccess'
    })
  } else {
    window.SzdUserInfoJsbridge && window.SzdUserInfoJsbridge.getTokenRaw('getTokenRawSuccess')
  }
}

function getNewTokenRaw() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('getNewTokenRaw', {
      getNewTokenRaw: 'getNewTokenRawSuccess'
    })
  } else {
    window.SzdUserInfoJsbridge && window.SzdUserInfoJsbridge.getNewTokenRaw('getNewTokenRawSuccess')
  }
}

//  压缩图片
function doPhotoCompress(callbackfname, paramJson) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('doPhotoCompress', {
      callbackfname: callbackfname,
      paramJson: JSON.stringify(paramJson)
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.doPhotoCompress(callbackfname, JSON.stringify(paramJson))
  }
}
//  选择图片并返回压缩后的图片
function doSelectPhoto(callbackfname, maxByteCount) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('doSelectPhoto', {
      callbackfname: callbackfname,
      maxByteCount: maxByteCount
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.doSelectPhoto(callbackfname, maxByteCount)
  }
}

function doTakePhoto(photo, token, url) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('doTakePhoto', {
      token: token,
      doTakePhoto: photo,
      url: url
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.doTakePhoto(photo, token)
  }
}

function doTakeVideo(video, token, url) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('doTakeVideo', {
      token: token,
      doTakeVideo: video,
      url: url
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.doTakeVideo(video, token)
  }
}

function gotoQuiteOauth(appid, scope, pageName, pageImg, pageUrl) {
  let urlLink = 'https://szdh5.suzhou.gov-cn-protected.example.org/#' + '/authorization/quiteOauth?' + "appid=" + appid + "&scope=" + scope + '&pageName=' + pageName + '&pageImg=' + pageImg + '&pageUrl=' + pageUrl;
  location.replace(urlLink);
}

function gotoOauth(appid, scope, pageName, pageImg, pageUrl) {
  let urlLink = 'https://szdh5.suzhou.gov-cn-protected.example.org/#' + '/authorization/auth?' + "appid=" + appid + "&scope=" + scope + '&pageName=' + pageName + '&pageImg=' + pageImg + '&pageUrl=' + pageUrl;
  location.replace(urlLink);
}
// 异步函数，防止阻塞
async function showServiceIntro(pageParam) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('showServiceIntro', {
      showServiceIntro: pageParam
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.showServiceIntro(pageParam)
  }
}

async function showRightNavIntro(pageParam) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('showRightNavIntro', {
      showRightNavIntro: pageParam
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.showRightNavIntro(pageParam)
  }
}

function doRealNameAuth(realname) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('doRealNameAuth', {
      doRealNameAuth: realname
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.doRealNameAuth(realname)
  }
}

function doSelfFaceAuth(scan) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('doSelfFaceAuth', {
      doSelfFaceAuth: scan
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.doSelfFaceAuth(scan)
  }
}

function doLocalLivenessInvalidate(scan) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('doLocalLivenessInvalidate', {
      doLocalLivenessInvalidate: scan
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.doLocalLivenessInvalidate(scan)
  }
}

function nativeLogin(login) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('nativeLogin', {
      nativeLogin: login
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.nativeLogin(login)
  }
}

function faceAuthFlag(callBack) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('faceAuthFlag', function (res) {
      callBack(res)
    })
  } else {
    window.CommonJsbridge && callBack(window.CommonJsbridge.faceAuthFlag())
  }
}

function getUserInfo(callBack) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('getUserInfo', function (res) {
      callBack(res)
    })
  } else {
    window.CommonJsbridge && callBack(window.CommonJsbridge.getUserInfo())
  }
}

function nativeGetRquest(id, url) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('nativeGetRquest', {
      id: id,
      url: url
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.nativeGetRquest(id, url)
  }
}

function nativePostRquest(id, url, params) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('nativePostRquest', {
      id: id,
      url: url,
      params: JSON.stringify(params)
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.nativePostRquest(id, url, JSON.stringify(params))
  }
}

function nativePostJsonRequest(id, url, params) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('nativePostJsonRequest', {
      id: id,
      url: url,
      params: JSON.stringify(params)
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.nativePostJsonRequest(id, url, JSON.stringify(params))
  }
}

function getNativeLocation() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('startLocate', {
      startLocate: 'getPosition'
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.startLocate('getPosition')
  }
}

function startLocateSilently() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('startLocateSilently', {
      startLocate: 'getPosition'
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.startLocateSilently('getPosition')
  }
}

function dail(phone) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('dail', {
      phone
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.dail(phone)
  }
}

function call(phone) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('call', {
      phone
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.call(phone)
  }
}

function openPage(pageRoute, pageParams) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('openPage', {
      pageRoute,
      pageParams
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.openPage(pageRoute, pageParams)
  }
}

function enableInterceptBackPressed(func) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('enableInterceptBackPressed', {
      func
    })
  }
}

function sukangma(func) {
  if (isIOS()) {
    window.closeWindow()
  }
}

function openBrowser(url) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('openBrowser', {
      openBrowser: url
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.openBrowser(url)
  }
}

function openPageWithPop(pageRoute, pageParams) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('openPageWithPop', {
      pageRoute,
      pageParams
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.openPageWithPop(pageRoute, pageParams)
  }
}

function openNewsDetail(path, newsId, publishId, title) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('openNewsDetail', {
      path: path,
      newsId: newsId,
      publishId: publishId,
      title: title
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.openNewsDetail(path, newsId, publishId, title)
  }
}

function hideTitleBar() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('hideTitleBar')
  } else {
    window.CommonJsbridge && window.CommonJsbridge.hideTitleBar()
  }
}

function showTitleBar() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('showTitleBar')
  } else {
    window.CommonJsbridge && window.CommonJsbridge.showTitleBar()
  }
}

function closeWindow() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('closeWindow')
  } else {
    window.CommonJsbridge && window.CommonJsbridge.closeWindow()
  }
}

function closeApp() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('closeApp')
  } else {
    window.CommonJsbridge && window.CommonJsbridge.closeApp()
  }
}

function goToMainNormal() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('goToMainNormal')
  } else {
    window.CommonJsbridge && window.CommonJsbridge.goToMainNormal()
  }
}

function toast(info) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('toast', info)
  } else {
    window.CommonJsbridge && window.CommonJsbridge.toast(info)
  }
}

function showLoadingDialog(tips) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('showLoadingDialog', tips)
  } else {
    window.CommonJsbridge && window.CommonJsbridge.showLoadingDialog(tips)
  }
}

function dismissLoadingDialog() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('dismissLoadingDialog')
  } else {
    window.CommonJsbridge && window.CommonJsbridge.dismissLoadingDialog()
  }
}

function getCancelType(callBack) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('getCancelType', function (res) {
      callBack(res)
    })
  } else {
    window.LogOffJsBridge && callBack(window.LogOffJsBridge.getCancelType())
  }
}

function getStatusBarHeightInPixel(callBack) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('getStatusBarHeightInPixel', function (res) {
      callBack(res)
    })
  } else {
    window.CommonJsbridge && callBack(window.CommonJsbridge.getStatusBarHeightInPixel())
  }
}
//安卓独有
function getStatusBarHeightInDp(callBack) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('getStatusBarHeightInDp', function (res) {
      callBack(res)
    })
  } else {
    window.CommonJsbridge && callBack(window.CommonJsbridge.getStatusBarHeightInDp())
  }
}

function getCancelCause(callBack) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('getCancelCause', function (res) {
      callBack(res)
    })
    // return WebViewJavascriptBridge.callHandler('getCancelCause')
  } else {
    window.LogOffJsBridge && callBack(window.LogOffJsBridge.getCancelCause())
  }
}

function onLogOffSuccess() {
  if (isIOS()) {
    return WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('onLogOffSuccess')
  } else {
    return window.LogOffJsBridge && window.LogOffJsBridge.onLogOffSuccess()
  }
}

function share(title, content, iconUrl, pageUrl) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('share', {
      title: title,
      content: content,
      iconUrl: iconUrl,
      pageUrl: pageUrl
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.share(title, content, iconUrl, pageUrl)
  }
}

function shareToWechat(title, content, iconUrl, pageUrl) {
  if (isIOS()) {
    return WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('shareToWechat', {
      title: title,
      content: content,
      iconUrl: iconUrl,
      pageUrl: pageUrl
    })
  } else {
    return window.CommonJsbridge && window.CommonJsbridge.shareToWechat(title, content, iconUrl, pageUrl)
  }
}

function shareToWechatCircle(title, content, iconUrl, pageUrl) {
  if (isIOS()) {
    return WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('shareToWechatCircle', {
      title: title,
      content: content,
      iconUrl: iconUrl,
      pageUrl: pageUrl
    })
  } else {
    return window.CommonJsbridge && window.CommonJsbridge.shareToWechatCircle(title, content, iconUrl, pageUrl)
  }
}
//  分享图片
function shareImageToWechat(base64) {
  if (isIOS()) {
    return WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('shareImageToWechat', base64)
  } else {
    return window.CommonJsbridge && window.CommonJsbridge.shareImageToWechat(base64)
  }
}

function shareToQQ(title, content, iconUrl, pageUrl) {
  if (isIOS()) {
    return WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('shareToQQ', {
      title: title,
      content: content,
      iconUrl: iconUrl,
      pageUrl: pageUrl
    })
  } else {
    return window.CommonJsbridge && window.CommonJsbridge.shareToQQ(title, content, iconUrl, pageUrl)
  }
}

function saveFile(fileName, fileStringData) {
  if (isIOS()) {
    return WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('saveFile', {
      fileName: fileName,
      fileStringData: fileStringData
    })
  } else {
    return window.CommonJsbridge && window.CommonJsbridge.saveFile(fileName, fileName)
  }
}

function saveFileByBase64(fileName, fileBStringData) {
  if (isIOS()) {
    return WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('saveFileByBase64', {
      fileName: fileName,
      fileBStringData: fileBStringData
    })
  } else {
    return window.CommonJsbridge && window.CommonJsbridge.saveFileByBase64(fileName, fileBStringData)
  }
}

function saveFileToGalleryByBase64(fileName, fileBStringData) {
  if (isIOS()) {
    return WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('saveFileToGalleryByBase64', {
      fileName: fileName,
      fileBStringData: fileBStringData
    })
  } else {
    return window.CommonJsbridge && window.CommonJsbridge.saveFileToGalleryByBase64(fileName, fileBStringData)
  }
}

function saveLocalData(paramJson) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('saveLocalData', paramJson)
  } else {
    window.CommonJsbridge && window.CommonJsbridge.saveLocalData(paramJson)
  }
}

function getNativeBehaviorInfo(callBack) {
  if (isIOS()) {
    return WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('getNativeBehaviorInfo', function (res) {
      callBack(res)
    })
  } else {
    return window.CommonJsbridge && callBack(window.CommonJsbridge.getNativeBehaviorInfo())
  }
}

function nativeBehaviorStatistics(info) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('nativeBehaviorStatistics', info)
  } else {
    window.CommonJsbridge && window.CommonJsbridge.nativeBehaviorStatistics(info)
  }
}

function jumpToWXMiniProgram(miniAppId, miniAppUrl) {
  if (isIOS()) {
    return WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('jumpToWXMiniProgram', {
      miniAppId: miniAppId,
      miniAppUrl: miniAppUrl
    })
  } else {
    return window.CommonJsbridge && window.CommonJsbridge.jumpToWXMiniProgram(miniAppId, miniAppUrl)
  }
}

function getNativeInfo(callBack) {
  if (isIOS()) {
    return WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('getNativeInfo', function (res) {
      callBack(res)
    })
  } else {
    return window.CommonJsbridge && callBack(window.CommonJsbridge.getNativeInfo())
  }
}

function isAppInstalledByScheme(packagename, callBack) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('isAppInstalledByScheme', packagename, function (res) {
      callBack(res)
    })
  } else {
    window.CommonJsbridge && callBack(window.CommonJsbridge.isAppInstalledByScheme(packagename))
  }
}

function jumpToOtherAppByScheme(packagename) {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('jumpToOtherAppByScheme', packagename)
  } else {
    window.CommonJsbridge && window.CommonJsbridge.jumpToOtherAppByScheme(packagename)
  }
}

function doCarLicensePlateRecognition() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('doCarLicensePlateRecognition', {
      doCarLicensePlateRecognition: 'doCarSuccess'
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.doCarLicensePlateRecognition('doCarSuccess')
  }
}

function openScanner() {
  if (isIOS()) {
    WebViewJavascriptBridge && WebViewJavascriptBridge.callHandler('openScanner', {
      openScanner: 'scanSuccess'
    })
  } else {
    window.CommonJsbridge && window.CommonJsbridge.openScanner('scanSuccess')
  }
}


// 埋点公用方法
function behavior(obj) {
  getNativeBehaviorInfo(res => {
    let info = Object.assign(obj, JSON.parse(res));
    nativeBehaviorStatistics(JSON.stringify(info));
  });

}

// 客户端响应

var resData = {}
// get请求
function h5GetResponse(res) {
  handleData(res)
}
//post请求
function h5PostResponse(res) {
  handleData(res)
}

function handleData(res) {
  let json = res.indexOf('{') > -1 && JSON.parse(res)
  if (JSON.stringify(json.res).indexOf('{') === -1) {
    resData[json.callId] = json.res
    return
  }
  json.res = JSON.parse(json.res)
  resData[json.callId] = json.res
}
//获取最终数据
function dispatch(request) {
  return new Promise(resolve => {
    Object.defineProperty(resData, request, {
      set: function (data) {
        resolve(data)
      }
    })
  })
}