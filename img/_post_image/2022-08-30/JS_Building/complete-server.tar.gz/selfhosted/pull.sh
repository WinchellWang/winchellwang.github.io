#!/bin/bash
files=(
https://szhsmtx.gaj.suzhou.com.cn/szsmtx/index.html
https://szhsmtx.gaj.suzhou.com.cn/cdn/vant/3.4.6/index.css
szsmtx/static/assets/banner.e4a4cb38.png
szsmtx/favicon.ico
szsmtx/static/js/index-25415d52.js
szsmtx/static/js/plugin-vue_export-helper-46f75680.js
szsmtx/static/js/success-40ed772d.js
szsmtx/static/js/dai-4e3a2c8f.js
szsmtx/static/js/rexian-ceaf5125.js

# Updated: new files at May 15
szsmtx/static/css/index-a4f61b89.css
szsmtx/static/js/index-20e963dd.js
szsmtx/static/js/vendor-bff34c93.js
szsmtx/static/js/index-bf112134.js
szsmtx/static/js/index-22917a00.js
szsmtx/static/js/wx-0c50b436.js
szsmtx/static/css/index-0abbd857.css
szsmtx/static/css/index-88b18820.css
szsmtx/static/js/index-f1c0622a.js
szsmtx/static/js/base-a9f5764b.js
szsmtx/static/css/index-69f8ce80.css
szsmtx/static/js/index-6f59c347.js
szsmtx/static/css/index-31dd55cb.css
szsmtx/static/css/index-39221b75.css
szsmtx/static/css/index-956b9106.css
szsmtx/static/js/index-86cd6561.js
szsmtx/static/js/index-c7412556.js
szsmtx/static/js/index-837947fe.js
szsmtx/static/css/index-b40c07cd.css
szsmtx/static/css/traffic-4dd15d6b.css
szsmtx/static/js/index-7654d964.js
szsmtx/static/js/traffic-93b4e829.js
szsmtx/static/js/index-ca99d3c3.js
szsmtx/static/css/index-76931f80.css
szsmtx/static/js/index-84602a5c.js
szsmtx/static/assets/nucle.cf6a148d.png
szsmtx/static/css/index-0bf70a65.css
szsmtx/static/js/index-d1d52471.js
szsmtx/static/css/index-609ae95d.css
szsmtx/static/js/index-3a16b51c.js

https://szdh5.suzhou.gov.cn:443/js/jsbridge.js
https://szhsmtx.gaj.suzhou.com.cn:443/cdn/pinia/2.0.11/pinia.iife.prod.js
https://szhsmtx.gaj.suzhou.com.cn:443/cdn/su/jsbridge-v2.js
https://szhsmtx.gaj.suzhou.com.cn:443/cdn/vant/3.4.6/vant.min.js
https://szhsmtx.gaj.suzhou.com.cn:443/cdn/vue/3.2.29/vue.global.prod.js
https://szhsmtx.gaj.suzhou.com.cn:443/cdn/vue-demi/0.12.1/index.iife.min.js
https://szhsmtx.gaj.suzhou.com.cn:443/cdn/vue-router/4.0.12/vue-router.global.prod.js
)

for url in "${files[@]}"; do
    echo "$url" | grep https || url="https://szhsmtx.gaj.suzhou.com.cn/$url"

    path=`echo "$url" | sed 's|https://[^/]*/||g'`
    # [[ "$path" != "szsmtx/index.html" ]] && [[ -f "$path" ]] && echo "Skipping $path because already existing..." && continue
    mkdir -p `dirname "$path"`
    wget "$url" -O "$path" --user-agent="Mozilla/5.0 (Linux; Android 8.0.0; SM-N9500 Build/R16NW; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/63.0.3239.83 Mobile Safari/537.36 T7/10.13 baiduboxapp/10.13.0.11 (Baidu; P1 8.0.0)"
done

## patch them (not allow rerun)

# Use HTTP GET to request API. 
sed -i 's/xHttp.post/xHttp.get/g' ./szsmtx/static/js/index-22917a00.js ./szsmtx/static/js/index-20e963dd.js
# It will think everything as Su-Zhou-Dao app
sed -i 's/szd_SZGov/ /g' ./js/jsbridge.js ./cdn/su/jsbridge-v2.js szsmtx/static/js/index-20e963dd.js
# Remove hardcoded hostname, use rel path
sed -i 's|//szhsmtx.gaj.suzhou.com.cn||g' szsmtx/static/js/index-20e963dd.js szsmtx/index.html
# Bug fix: fucking wechat is breaking the button
sed -i 's/s=await C()/s=null/g' szsmtx/static/js/index-86cd6561.js
# Sometimes the script access /szsmtx/szsmtx because of some error. Add a symlink to workaround it. 
rm -f szsmtx/szsmtx && ln -s . szsmtx/szsmtx

# Remove all possible tracing code
sed -i 's/gov\.cn/gov-cn-protected.example.org/g' ./cdn/su/jsbridge-v2.js ./js/jsbridge.js szsmtx/static/js/index-20e963dd.js
sed -i 's/com\.cn/com-cn-protected.example.org/g' szsmtx/static/js/index-20e963dd.js
echo "Removing the following domains from javascript: "
grep '[a-zA-Z0-9-][a-zA-Z0-9-][a-zA-Z0-9-]*\.com[^a-zA-Z0-9]' -o -r cdn js szsmtx | grep -v png | tee /tmp/o
sed -i 's/[a-zA-Z0-9-][a-zA-Z0-9-][a-zA-Z0-9-]*\.com[^a-zA-Z0-9]/protected-code.example.org/g' $(cat /tmp/o | cut -d : -f 1)


