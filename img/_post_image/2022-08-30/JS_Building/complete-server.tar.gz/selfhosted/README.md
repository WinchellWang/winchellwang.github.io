

## How to use

publish this directory as webroot, and visit <http://YOUR-WEBSITE.com/szsmtx/?dzwym=1&timestamp=1&code=1>

To modify your location, please modify `api/weixin/getCodeInfo`

## How to reproduce my work

1. run pull.sh to download all website. It must be in webroot. 
2. create `api/` and fill all api response. (If the api interface has changed, you need to run NetCapture on your android phone to see the latest interface.)
3. visit <http://YOUR-WEBSITE.com/szsmtx/?dzwym=1&timestamp=1&code=1> (If there is some 404, please add all missing file to pull.sh and run it again. )


